shriram@shriram-VirtualBox:~$ cd Documents
shriram@shriram-VirtualBox:~/Documents$ ls
shriram@shriram-VirtualBox:~/Documents$ touch M1_Q1
shriram@shriram-VirtualBox:~/Documents$ ls
M1_Q1
shriram@shriram-VirtualBox:~/Documents$ ls -l
total 0
-rw-rw-r-- 1 shriram shriram 0 Jan 23 08:11 M1_Q1
shriram@shriram-VirtualBox:~/Documents$ chmod a=x M1_Q1
shriram@shriram-VirtualBox:~/Documents$ ls -l
total 0
---x--x--x 1 shriram shriram 0 Jan 23 08:11 M1_Q1

